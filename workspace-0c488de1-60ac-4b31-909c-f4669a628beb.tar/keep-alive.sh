#!/bin/bash
cd /home/z/my-project
while true; do
  bun run dev 2>&1
  echo "=== Server exited at $(date), restarting... ==="
  sleep 3
done
